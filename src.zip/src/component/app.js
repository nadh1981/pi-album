import "react-vis/dist/style.css";
import React, { useState, useEffect, Component }from "react";
import { getCurrentDate, getCurrentDay, isItDaytime } from "./utilities";
import ButtonHeartrate from 'ButtonHeartrate.js';
import DetailedHeartrate from './Components/DetailedHeartrate.js';
import axios from 'axios';
import styled from "styled-components";
import { Button, ButtonGroup } from "@chakra-ui/react"
import { Link } from "@chakra-ui/react"


export default function App() {
  const [theme, setTheme] = useState({});

  const lightTheme = {
    leftMenuBackground: "#001a33",
    leftTextColor: "white",
    leftMenu: "rgba(77,77,77,0.4)",
    rigthMenuBackground: "#e9eff5",
    rightMenu: "white",
    rightTextColor: "black",
  };

  const darkTheme = {
    leftMenuBackground: "#001a33",
    leftTextColor: "white",
    leftMenu: "rgba(77,77,77,0.4)",
    rigthMenuBackground: "#001a33",
    rightMenu: "rgba(77,77,77,0.4)",
    rightTextColor: "white",
  };


  function getRandomIndex(index){
    return index = Math.floor((Math.random() * 4) + 0);
  }


const getColour = async () => {
    try {
      var i = 0
        const res = await axios.get('http://127.0.0.1:8000/button/' + getRandomIndex(i))
        console.log(res.data);
        return res.data
    } catch (err) {
        // Handle Error Here
        console.error(err);
    }
};


var colour = getColour()
console.log(colour)

  var x = "blue"
  const CustomButton = styled.a`
    /* This renders the buttons above... Edit me! */
    display: inline-block;
    border-radius: 3px;
    padding: 0.5rem 0;
    margin: 0.5rem 1rem;
    width: 11rem;
    border: 2px solid ${props => x};
    backgroundColor ${props => x};
  `





  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    console.log("useeffect");
    setTheme(loadTheme());
    // eslint-disable-next-line
  }, []);

  const loadTheme = () => {
    let daytime = isItDaytime();
    console.log(daytime);
    if (daytime) {
      return lightTheme;
    }
    return darkTheme;
  };



  return (


    <div className="container-fluid" style={{ height: "100%" }}>
      {/* LEFT SIDE MENU */}

      <div className="row h-100">
        <div
          className="col-3"
          style={{ backgroundColor: theme.leftMenuBackground }}>
          <div className="row firstRow">
            <div
              className="col-12 text-center w-75 mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.leftTextColor,
                backgroundColor: theme.leftMenu,
                borderRadius: "15px",
              }}
            >
              {getCurrentDay()}
              <br />
              {getCurrentDate()}
            </div>
          </div>

          {/* PATIENT 1 NAME  */}
          <div className="row mt-4" style={{ height: "10%" }}>
            <div
              className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.leftTextColor,
                backgroundColor: theme.leftMenu,
                borderRadius: "15px",
              }}
            >
              Belinda
            </div>
          </div>

          {/* PATIENT 2 NAME */}
          <div className="row mt-4" style={{ height: "10%" }}>
            <div
              className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.leftTextColor,
                backgroundColor: theme.leftMenu,
                borderRadius: "15px",
              }}
            >
              Nathan
            </div>
          </div>

          {/* PATIENT 3 NAME */}
          <div className="row mt-4" style={{ height: "10%" }}>
            <div
              className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.leftTextColor,
                backgroundColor: theme.leftMenu,
                borderRadius: "15px",
              }}
            >
              Isaac
            </div>
          </div>
        </div>



        {/* RIGHT SIDE MENU */}

        <div
          className="col-9"
          style={{ backgroundColor: theme.rigthMenuBackground }}
        >


        {/* DAY (TOP OF SCREEN) */}
          <div
            className="row secondRow"
            style={{ marginTop: "9%", height: "4%" }}
          >
            <div
              className="col-11 text-center mx-auto d-flex align-items-center justify-content-left"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
              }}
            >
              <strong>Day</strong>
            </div>
          </div>



          {/* COLUMN ONE-- HEART */}

          <div className="row secondColumn">
            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
                maxHeight: "100%",
                position: "relative",
              }}
            >
              <img
                className="img-fluid"
                style={{ height: "40%" }}
                src="https://cdn-icons-png.flaticon.com/512/865/865969.png"
                alt="Heart rate"
              ></img>
              <span
                style={{
                  position: "absolute",
                  bottom: "10%",
                  display: "inline-block",
                }}
              >
                <strong>Heart Rate</strong>
              </span>
            </div>


            {/* COLUMN TWO -- STEPS */}

            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
                maxHeight: "100%",
                position: "relative",
              }}
            >
              <img
                className="img-fluid"
                style={{ height: "40%" }}
                src="https://cdn-icons-png.flaticon.com/512/865/865969.png"
                alt="Heart rate"
              ></img>
              <span
                style={{
                  position: "absolute",
                  bottom: "10%",
                  display: "inline-block",
                }}
              >
                <strong>Steps</strong>
              </span>
            </div>



            {/* COLUMN THREE -- SLEEP */}

            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
                maxHeight: "100%",
                position: "relative",
              }}
            >
              <img
                className="img-fluid"
                style={{ height: "40%" }}
                src="https://cdn-icons-png.flaticon.com/512/865/865969.png"
                alt="Heart rate"
              ></img>
              <span
                style={{
                  position: "absolute",
                  bottom: "10%",
                  display: "inline-block",
                }}
              >
                <strong>Sleep</strong>
              </span>
            </div>
          </div>




          {/* FIRST ROW OF BUTTONS */}

          <div className="row mt-4" style={{ height: "10%" }}>

          {/* BELINDA HEART BUTTON */}
            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
              }}>


              <CustomButton href="heartrate">
              </CustomButton>


            </div>

            {/* BELINDA STEPS BUTTON */}
            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
              }}
            >

              <Link to="/placeholder" className="btn btn-outline-danger w-25">
                --
              </Link>
            </div>


            {/* BELINDA SLEEP BUTTON */}
            <div
              className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
              style={{
                color: theme.rightTextColor,
                backgroundColor: theme.rightMenu,
                borderRadius: "15px",
              }}
            >
              <Link to="/placeholder" className="btn btn-outline-success w-25">
                --
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import NotFound from "./NotFound";
import App from "App.js";
import DetailedHeartrate from "./Components/DetailedHeartrate.js"
import DetailedSteps from "./Components/DetailedSteps.js"
import DetailedSleep from "./Components/DetailedSleep.js"
import ButtonHeartrate from "./ButtonHeartrate.js"


const Routes = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/" exact component={ButtonHeartrate}></Route>
        <Route path="/heartrate" exact component={DetailedHeartrate}></Route>
        <Route path="/steps" exact component={DetailedSteps}></Route>
        <Route path="/sleep" exact component={DetailedSleep}></Route>
        <Route component={NotFound}></Route>
      </Switch>
    </BrowserRouter>
  );
};

export default Routes;

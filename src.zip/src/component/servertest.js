var express = require('express');
var app = express();
var cors = require('cors');
app.use(cors())
app.get('/heart', function (req, res) {
 
    var sql = require("mssql");

    // config for your database
    var config = {
        user: 'sa',
        password: 'magiczac',
        server: 'localhost', 
        database: 'Sample', 
        options: {
            encrypt: false
        }
    };

    // connect to your database
    sql.connect(config, function (err) {
    
        if (err) console.log(err);

        // create Request object
        var request = new sql.Request();
           
        // query to the database and get the records
        request.query('SELECT heartrate FROM heartratefor1032021;', function (err, heartrate) {
            
            if (err) console.log(err)
      
            // send records as a response
            res.send(heartrate);
            
            
        });
    });
});
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
    });

var server = app.listen(5000, function () {
    console.log('Server is running..');
});
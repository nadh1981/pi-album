import React, {useState, useEffect, Component} from 'react';
import { Paper, Container, Grid, Stack ,Typography, Card, CardContent, Button} from '@mui/material';
import { Box, display, height, styled } from '@mui/system';
import { getCurrentDate, getCurrentDay } from "../utilities";
import { Link } from 'react-router-dom';
import PersonIcon from '@mui/icons-material/Person';




export default function Dashboard() {
    var array = [73,71,66,66,65,65,66,67,64,64,66,65,64,90,70,61,62,66,64,61,62,61,68,63,62,64,65,64,64,68,63,65,63,61,65,62,61,62,61,62,62,63,66,62,62,60,61,61,61,62,62,62,62,68,72,63,66,60,61,60,61,60,61,62,61,62,63,64,60,61,61,61,61,62,61,63,61,58,58,57,61,64,67,61,62,63,61,59,58,60,62,61,60,64,63,62,61,62,61,62,62,61,60,59,59,59,59,59,57,56,56,57,56,57,57,57,57,57,56,57,57,59,59,58,59,59,58,60,58,58,59,60,59,58,65,63,63,57,55,55,60,58,58,59,56,55,57,57,57,59,58,57,61,61,63,62,61,63,62,63,63,61,61,60,61,60,60,58,59,61,61,62,59,60,60,61,59,61,60,58,59,60,61,60,60,60,60,61,59,61,55,56,59,64,57,58,58,56,57,58,56,54,55,58,54,58,58,60,66,65,61,59,57,59,58,61,66,60,58,55,56,57,59,56,58,59,59,58,60,59,59,57,58,58,59,58,57,59,59,59,64,67,64,61,59,63,76]
      
     
    const min = Math.min(...array);
    const max = Math.max(...array);

    return (
        //layout of page.
        <Grid container flexGrow> 
            <Grid item lg={6} md={6} xs={12}>
                <Grid container>
                    <Grid item lg={3} md={3} xs={12}
                    style={{
                        backgroundColor:"#001a33"
                    }}
                    >
                        <Box className="left-menu-card">
                            <Stack spacing={2}>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    height:"90px",
                                    padding:"5px",
                                }}
                                >{
                                //get currentday
                                getCurrentDay()}
                                <br/>
                                {
                                //get current date
                                getCurrentDate()}
                                </Paper>
                            </Stack>
                            <Stack direction="column" spacing={1}>   
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Belinda</Button>
                                </Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Isaac</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"18px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Nathan</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"18px",
                                
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Patient 4</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Patient 5</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Patient 6</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Patient 7</Button></Paper>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    marginTop:"20px",
                                }}
                                ><Button color="inherit" startIcon={<PersonIcon/>}>Patient 8</Button></Paper>
                            </Stack>
                        </Box>

                    </Grid>
                    <Grid item lg={9} md={9} xs={12}
                    style={{backgroundColor:"#e9eff5"}}
                    >
                        <Box className="day-main-menu">
                            <Stack spacing={2}>
                                <Paper elevation={0}
                                style={{
                                    padding:"10px",
                                    fontWeight:"bold",
                                    marginBottom:"10px"
                                }}
                                >Day</Paper>       
                            </Stack>
                            <Stack marginTop="5px" direction="row" spacing={1}>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                        <img src="image/outline_favorite_black_24dp.png" alt="exercise-heart-rate"/>
                                        <Box textAlign="center">
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Exercise heart rate
                                            </Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                            <img src="image/lungs-with-bronchi-.png" alt="breathing"/>
                                            <Box textAlign="center">
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Breathing
                                            </Typography>
                                        </Box>
                                    </CardContent>
                                    </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                            <img src="image/outline_thermostat_black_24dp.png" alt="temparature"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Temperature
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                            <img src="image/outline_touch_app_black_24dp.png" alt="pulse-oximeter"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Pulse oximeter
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                            <img src="image/human-footprint.png" alt="steps"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Steps
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center"}}>
                                    <CardContent>
                                            <img src="image/travel.png" alt="distance-traveled"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Distance traveled
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                                <Paper className="paperClass">
                                    <Link to="/heart" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    href="/blankpage"
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/steps" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>
                            <Stack marginTop="15px" direction="row" spacing={1}>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >min is {min},max is {max}</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper className="paperClass">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                    size="small"
                                    variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>
                        </Box>
                    </Grid>
                </Grid>
            </Grid>     
            <Grid item lg={6} md={6} xs={12}>
            <Grid container>
                    <Grid item lg={10} md={10} xs={12}
                    style={{
                        backgroundColor:"#001a33"
                    }}
                    >
                        <Box className="night-center-menu">
                            <Stack spacing={2}>
                                <Paper elevation={0}
                                style={{
                                    backgroundColor:"rgba(77,77,77,0.4)",
                                    color:"white",
                                    padding:"10px",
                                    fontWeight:"bold",
                                    marginBottom:"10px"
                                }}
                                >Night</Paper>       
                            </Stack>
                            <Stack marginTop="5px" direction="row" spacing={1}>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                        <img src="image/Night/outline_nightlight_round_white_24dp.png" alt="hours-of-sleep"/>
                                        <Box textAlign="center">
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Hours of sleep
                                            </Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/outline_favorite_white_24dp.png" alt="resting-heart-rate"/>
                                            <Box textAlign="center">
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Resting heart rate
                                            </Typography>
                                        </Box>
                                    </CardContent>
                                    </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/cardiogram.png" alt="heart-rate-variability"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Heart rate variability
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/lungs-with-bronchi-.png" alt="breathing"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Breathing
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/outline_thermostat_white_24dp.png" alt="temperature"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Temperature
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/outline_touch_app_white_24dp.png" alt="pulse-oximeter"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Pulse oximeter
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                                <Card style={{width:"130px", height:"90px",textAlign:"center",backgroundColor:"rgba(77,77,77,0.4)",color:"white"}}>
                                    <CardContent>
                                            <img src="image/Night/human-footprint.png" alt="steps"/>
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Steps
                                            </Typography>
                                        </Box>
                                    </CardContent>
                
                                </Card>
                            </Stack>
                            <Stack marginTop="15px" direction="row" spacing={1}>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/sleep" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>
                            <Stack marginTop="15px" direction="row" spacing={1}>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>

                            <Stack marginTop="15px" direction="row" spacing={1}>
                            <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                                <Paper style={{backgroundColor:"rgba(77,77,77,0.4)"}} className="paperClass-night">
                                    <Link to="/blankpage" style={{textDecoration:"none"}}>
                                    <Button 
                                        size="small"
                                        variant="outlined"
                                    >--</Button>
                                    </Link>
                                </Paper>
                            </Stack>
                        </Box>
                    </Grid>
                    <Grid item lg={2} md={2} xs={12} style={{backgroundColor:"#e9eff5"}}>
                        <Box margin="10px" marginTop="65px" textAlign="center">
                    
                            <Card style={{width:"100px", height:"90px",textAlign:"center"}} variant="outlined">
                                    <CardContent>
                                            <img src="image/old-man-walking.png" />
                                            <Box>
                                            <Typography
                                                variant="inherit"
                                                fontSize="8pt"
                                                fontWeight="bold"
                                                >
                                                Fall<br/> detection
                                            </Typography>
                                        </Box>
                                    </CardContent>
                                </Card>     
                                <Stack direction="column">
                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                    <Paper style={{marginTop:"15px",marginBottom:"7px"}} className="paperClass-right-menu">
                                        <Link to="/blankpage" style={{textDecoration:"none"}}>
                                        <Button 
                                        size="small"
                                        variant="outlined"
                                        >--</Button>
                                        </Link>
                                    </Paper>

                                </Stack>
                        </Box> 
                    </Grid>
                </Grid>
            </Grid>  
        </Grid>
        
    )
}
// var i = 0
// function changeColour(){
//     i++
//     if(i>2){i=0}
//     
// }


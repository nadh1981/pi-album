import React, { Component } from 'react'
import axios from 'axios'
import {XYPlot, XAxis, YAxis, HorizontalGridLines, VerticalBarSeries, LineSeries} from 'react-vis';

class StepsData extends Component {
  constructor(props) {
      super(props)
      this.state = {
        active: "",
        highlyActive: "",
        distance: "",
        sedentary: "",
        sleeping: "",
        steps: [],
        data: []
      }
  }

    componentDidMount() {
    axios.get('http://localhost:8080/')
      .then(response => {
        console.log(response.data)

        var steps = []
        for (var j in response.data.steps) {
           var obj = response.data.steps[j];
            steps.push(obj)
            }
        console.log(steps)

        var data = []
        var ts=0

        for(var k in steps)
        {
         data.push({x:ts+=1, y:steps[k]})
        }

        this.setState({
          active: JSON.stringify(response.data.active),
          highlyActive: JSON.stringify(response.data.highlyActive),
          distance: JSON.stringify(response.data.distance),
          sedentary: JSON.stringify(response.data.sedentary),
          sleeping: JSON.stringify(response.data.sleeping),
          steps: steps,
          data: data
        })


      })
      .catch(error => {
        console.log(error)
      })
  }

  render() {
    const {active, highlyActive, distance, sedentary, sleeping, steps, data} = this.state

    const stepsDataCollection = [
      {x: "Highly Active", y: parseInt(highlyActive)},
      {x: "Sedentary", y: parseInt(sedentary)},
    ]


    return (
      <div>
      <h1> Daily Steps Activity </h1>
      <div>

      <h3> Steps Over Time </h3>
      <p>{"Total Distance Moved: " + distance + "m"}</p>

      <XYPlot
        width={900}
        height={600}
        xPadding={5}
        yPadding={5}>
        <HorizontalGridLines />
        <XAxis Time of Day/>
        <YAxis Steps/>
        <LineSeries
          data={data}/>
      </XYPlot>
      <br/>
      <br/>


      <h3> Activity Levels </h3>

      <XYPlot
        xType = "ordinal"
        width={600}
        height={400}
        xPadding={5}
        yPadding={5}
        xDistance={100}

        >

        <HorizontalGridLines />

        <XAxis Light Deep and REM Sleep/>
        <YAxis Time Spent Asleep/>

        <VerticalBarSeries className="vertical-bar-series-example" data={stepsDataCollection}/>
      </XYPlot>
      </div>
    </div>

    )
  }
}
export default StepsData

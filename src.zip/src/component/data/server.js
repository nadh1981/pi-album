const { Connection, Request } = require("tedious");

// Create connection to database
const config = {
  authentication: {
    options: {
      userName: "sa", // The username for the SQL Database
      password: "magiczac" // The password for the SQL Database
    },
    type: "default"
  },
  server: "localhost", // Where the server is located
  options: {
    database: "Sample", //The database name 
    encrypt: true
  }
};

/* 
    //Use Azure VM Managed Identity to connect to the SQL database
    const config = {
        server: process.env["db_server"],
        authentication: {
            type: 'azure-active-directory-msi-vm',
        },
        options: {
            database: process.env["db_database"],
            encrypt: true,
            port: 1433
        }
    };

    //Use Azure App Service Managed Identity to connect to the SQL database
    const config = {
        server: process.env["db_server"],
        authentication: {
            type: 'azure-active-directory-msi-app-service',
        },
        options: {
            database: process.env["db_database"],
            encrypt: true,
            port: 1433
        }
    });

*/

const connection = new Connection(config);

// Attempt to connect to database and execute queries if connection goes through
connection.on("connect", err => {
  if (err) {
    console.error(err.message);
  } else {
    dor();
  }
});

connection.connect();


function dor() {
  
  var x = (function(){
    console.log("Reading rows from the Table...");

  // Read all rows from table
  var request = new Request(
    'select Time,Heartrate from Heartratetable', /// This is the SQL query to grab the heartrate columm and its values 
    (err, rowCount) => {
      if (err) {
        console.error(err.message);
      } else {
        console.log(`${rowCount} row(s) returned`);
      }
    }
  );
  hear = [];
    request.on("row", columns => {
      columns.forEach(column => {
      // console.log("%s\t%s", column.metadata.colName, column.value);

      let min = [column.value] //// refernce to the columm heartrate values in database
      // console.log(min); ///This prints out onto the console the values in the heartrate 
  
      hear.push(min)
      
  
 // for (let i = 0;  i < min.length; i++) { ///push heartrate values into hear array
  
 //}
 console.log("heart: "+hear);
 jsonArrData = JSON.stringify(hear)
 var http = require('http');
 http.createServer(function (req, res) {  ///server to put values on so another program can grab them. 
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader("Content-Type", "application/json");
    res.writeHead(200);
    res.end(jsonArrData);
}).listen(8082);

      });
    });
 
   connection.execSql(request);
   // I want this to equal hear put nothing is being filled in hear even tried global var. 
    ////Below array is what I should be in var heart but it is empty. 
   /// This should return the hear array so that it can be sent to other page and display the heartrate values.
  })(); 
  
}



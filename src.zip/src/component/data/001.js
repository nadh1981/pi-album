const axios = require('axios');

const fetchUsers = () => {
    axios.get('http://localhost:8080/')
        .then(response => {
            const users = response.data;
            console.log(users);
        })
        .catch(error => console.error(error));
};

fetchUsers();


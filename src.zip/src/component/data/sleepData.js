import React, { Component } from 'react'
import axios from 'axios'
import {XYPlot, XAxis, YAxis, HorizontalGridLines, LineSeries, VerticalBarSeries, VerticalBarSeriesCanvas,
 DiscreteColorLegend, Borders, LabelSeries} from 'react-vis';

function getRandomIndex(index){
  return index = Math.floor((Math.random() * 4) + 0);
}


class SleepData extends Component {
  constructor(props) {
      super(props)
      this.state = {
          totalSleep: "",
          deepSleep: "",
          lightSleep: "",
          remSleep: "",
          awakeSleep: "",
          sleepLevel: [],
          sleepStress: [],
          sleepRespiration: [],
          averageRespiration: "",
          lowestRespiration: "",
          highestRespiration: "",
          sleepLevelData: [],
          sleepStressData: [],
          sleepRespirationData: [],
        }
      }


    componentDidMount() {

       
      axios.get('http://localhost:8080/')
          .then(response => {
            console.log(response.data)
            var sleepLevel = []
            for (var i in response.data) {
              var obj = response.data[i];
                sleepLevel.push(obj)
                }
            console.log(sleepLevel)
            sleepLevel = sleepLevel.map(Number);
            console.log(sleepLevel);
            var timestamp = 0
            var sleepLevelData = []
            for(var s in sleepLevel)
            {
             sleepLevelData.push({x:timestamp+=1, y:sleepLevel[s]})
            }
            

            this.setState({
              sleepLevel: sleepLevel,
              sleepLevelData: sleepLevelData,
           
            })
          })
      
      axios.get('http://localhost:8888/')
          .then(response => {
            console.log(response.data)
            
            
          
            
            


           var a = 0
        var sleeptime = []
        for (var i in response.data) {
           var obj = response.data[i=a];
           sleeptime.push(parseInt(obj))
           break;
            }
        console.log(sleeptime)
        






        var b = 1
        var deepsleep = []
        for (var i in response.data) {
           var obj = response.data[i=b];
           deepsleep.push(parseInt(obj))
           break;
            }
        console.log(parseInt(obj))
    

        var c = 2
        var lightsleep = []
        for (var i in response.data) {
           var obj = response.data[i=c];
           lightsleep.push(parseInt(obj))
           break;
            }
        console.log(lightsleep)
       

        var d = 3
        var remsleep = []
        for (var i in response.data) {
           var obj = response.data[i=d];
           remsleep.push(parseInt(obj))
           break;
            }
        console.log(remsleep)
      
        var sleepLevel = []
        for (var i in response.data) {
          var obj = response.data[i];
            sleepLevel.push(obj)
            }




          
        var sleepStress = []
        for (var j in response.data) {
           var obj = response.data[j];
            sleepStress.push(obj)
            var obj = sleepStress[j];
            sleepStress.push(obj)
            }
        console.log(sleepStress)

        var sleepRespiration = []
        for (var k in response.data) {
           var obj = response.data[k];
            sleepRespiration.push(parseInt(obj))
            }
        console.log(sleepRespiration)

        var sleepLevelData = []
        var sleepStressData = []
        var sleepRespirationData = []

        var timestamp = 0
        for(var s in sleepLevel)
        {
         sleepLevelData.push({x:timestamp+=1, y:sleepLevel[s]})
        }

        timestamp=0 
        s=0
        for(var s in sleepStress)
        {
         sleepStressData.push({x:timestamp+=1, y:sleepStress[s]})
        }

        timestamp=0
        s=0
        for(var s in sleepRespiration)
        {
         sleepRespirationData.push({x:timestamp+=1, y:sleepRespiration[s]})
        }




        console.log(sleepRespirationData)


        this.setState({
          totalSleep: JSON.stringify(new Number(sleeptime)),
          deepSleep: JSON.stringify(new Number(deepsleep)),
          lightSleep: JSON.stringify(new Number(lightsleep)),
          remSleep: JSON.stringify(new Number(remsleep)),
          awakeSleep: JSON.stringify(response.data.awake_sleep_seconds),
          sleepStress: sleepStress,
          sleepRespiration: sleepRespiration,
          averageRespiration: JSON.stringify(response.data.average_respiration_value),
          lowestRespiration: JSON.stringify(response.data.lowest_respiration_value),
          highestRespiration: JSON.stringify(response.data.highest_respiration_value),
          sleepStressData: sleepStressData,
          sleepRespirationData: sleepRespirationData
        })
      })
      .catch(error => {
        console.log(error)
      })
  }

  render() {
   const {
     totalSleep, deepSleep, lightSleep, remSleep, awakeSleep,
     sleepLevel, sleepStress,
     sleepRespiration,averageRespiration,lowestRespiration,highestRespiration,
     sleepLevelData,sleepStressData,sleepRespirationData} = this.state

     console.log(sleepLevelData)
     console.log(sleepStressData)
     console.log(sleepRespirationData)

     const sleepDataCollection = [
       {x: "Light", y: parseInt(lightSleep)},
       {x: "Deep", y: parseInt(deepSleep)},
       {x: "REM", y: parseInt(remSleep)}
     ]


     console.log(sleepLevelData, sleepStressData, sleepRespirationData)
     console.log(sleepDataCollection)

     var temp = parseInt(totalSleep) / 3600
     var sleepHours = temp.toFixed(2)
     console.log(sleepHours)

     if(sleepLevel || sleepStressData || sleepRespirationData != 0)
     {

    return (
      <div>
      <h1> Daily Sleep Activity </h1>
      <div>

      <h3> Sleep Level Over Time </h3>
      <XYPlot
        width={900}
        height={600}
        xPadding={5}
        yPadding={5}>
        <HorizontalGridLines />
        <XAxis Time of Day/>
        <YAxis Sleep Level/>
        <LineSeries
          data={sleepLevelData}/>
      </XYPlot>
      <br/>
      <br/>



      <h3> Sleep Stress Level </h3>
      <p> 1 - 25: Not Stressful </p>
      <p> 26 - 50: Low Stress </p>
      <p> 51 - 75: Medium Stress </p>
      <p> 76 - 100: High Stress </p>

      <XYPlot
        width={900}
        height={600}
        xPadding={5}
        yPadding={5}>
        <HorizontalGridLines />
        <XAxis Time of Day/>
        <YAxis Sleep Stress/>
        <LineSeries
          data={sleepStressData}/>
      </XYPlot>
      <br/>
      <br/>




      <h3> Sleep Respiration Level (Breaths Per Minute)</h3>
      <p>{"Average Respiration: " + averageRespiration + "bpm"}</p>
      <p>{"Lowest Respiration: "+ lowestRespiration + "bpm"}</p>
      <p>{"Highest Respiration: " + highestRespiration + "bpm"}</p>

      <XYPlot
        width={900}
        height={600}
        xPadding={5}
        yPadding={5}>
        <HorizontalGridLines />
        <XAxis Time of Day/>
        <YAxis Sleep Respiration/>
        <LineSeries
          data={sleepRespirationData}/>
      </XYPlot>
      <br/>
      <br/>



      <h3> Light, Deep and REM Sleep (Seconds)</h3>
      <p>{"Total Sleep: "+ sleepHours +" hours"}</p>
      <XYPlot
        xType = "ordinal"
        width={900}
        height={600}
        xPadding={5}
        yPadding={5}
        xDistance={100}
        >

        <HorizontalGridLines />

        <XAxis Light Deep and REM Sleep/>
        <YAxis Time Spent Asleep/>

        <VerticalBarSeries className="vertical-bar-series-example" data={sleepDataCollection}/>
      </XYPlot>

      </div>
    </div>
    )

  }


  }
}

export default SleepData

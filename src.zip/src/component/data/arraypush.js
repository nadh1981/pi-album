var arr1 = [];
    for (a = 0; a < 35; a++)
    {
        var array = [55,33,22,32]
        arr1 = [];
        for (i = 0; i < 4; i++)
        {
            arr1.push('elem:' + array[i]);
        }
    }
    console.log(arr1)
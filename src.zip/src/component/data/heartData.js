import React, {Component }from "react";
import axios from 'axios';
import "react-vis/dist/style.css";////The libary used for graphing



import {
  XYPlot,
  XAxis,
  YAxis,
  VerticalGridLines,
  HorizontalGridLines,
  LineSeries
} from "react-vis";////The imports for rect vis libary graphing



class HeartData extends React.Component {
 

  constructor(props) {
      super(props)
      this.state = {
        max: "",
        min: "",
        heartRates: [],
        data: []
      }
    
      
  }

    componentDidMount() {
      axios.get('http://localhost:8082/') /// This is grabbing the json heartrate data from a port 
      .then(response => {
        console.log(response.data)
      var data = []
    
    
    var a = 1
    var b = 0
    const heartlevel = []
    for (var i in response.data) { 
      var obj = response.data[i=a];
        heartlevel.push(parseInt(obj)) ////This method is loading heartrate into the array
        a=a+2;
        }
    console.log(heartlevel)
      
    var hearttime = []
    var hearttiming = []
    for (var i in response.data) {  ////This is loading the time into a array though the format of the date is date then time not just time
      var obj = response.data[i=b];    
        hearttime.push(obj)
        b=b+2;
        }
  var f = 11
  var g = 5
        for (var i in hearttime) {   ////This is the method I am trying to use to get just the time from hearttime 
          let text = hearttime.toString(); //// It tostrings the array 
          var myTime = text.substr(f, g); /////Then grabs the time at a certain position in text 
          console.log(myTime);
          hearttiming.push(parseInt(myTime)) /// Then pushs the time into array though I am parse int I want to replace that with just the time number 
          f=f+25;  ///This make sure that it repeats each time 
            }
            var currentDate = new Date();
          
         
console.log(hearttiming)
    console.log(hearttime)

    var min = Math.min( ...heartlevel ),
    max = Math.max( ...heartlevel );
    console.log(max)
      for(var k in heartlevel) 
      {
          data.push({x:hearttiming[k], y:heartlevel[k]})  ////This is where the time and heartrate are grapbhed 
      }
      
      this.setState({      
        max: JSON.stringify(max), 
        min: JSON.stringify(min),
        date: currentDate,
        data: data /// Then their state is set 
      }) 
    })
  }
  

  render() {
   const {max, min, heartRates,date, data} = this.state
   console.log(data)
    return (

      <div>
        <h1>Daily Heat Rate </h1>

        <div>
        <p>{"Date is. " + date}</p>
        <p>{"Max Heart Rate. "+ max}</p>
        <p>{"Min Heart Rate. " + min}</p>

        <XYPlot
          width={1700}
          height={600}
          xPadding={15}
          yPadding={15}>
          <HorizontalGridLines />
          <VerticalGridLines />
          <XAxis Time of Day/>
          <YAxis Heart Rate/>
          
          <LineSeries
            data={data}/>
        </XYPlot>


        
        </div>
      </div>//////The data is graphed in the lineseries data with the xandyplot
      
    )
  }
}




// const BlankPage = () => {
//     var showData = new GetData()
//     return ( 
//         showData
//      );
// }

export default HeartData;


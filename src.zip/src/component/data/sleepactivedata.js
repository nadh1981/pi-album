var http = require('http');
const {active} = require('./sleepactiveserver.js');
  
  
var Hostel_Allocation = {
    student_age: active.age, 
    heart : active.heart /// this is where my array should come too then it should display in the server in localhost8080
}
jsonArrData = JSON.stringify(Hostel_Allocation.heart)

console.log(jsonArrData)


         
  
http.createServer(function (req, res) {  ///server to put values on so another program can grab them. 
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader("Content-Type", "application/json");
    res.writeHead(200);
    res.end(jsonArrData);
}).listen(8080);


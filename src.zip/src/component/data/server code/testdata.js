var http = require('http');
const {Student} = require('./server.js');
  
  
var Hostel_Allocation = {
    student_age: Student.age, 
    heart : Student.heart /// this is where my array should come too then it should display in the server in localhost8080
}
  
var str = "Heart: "
         + Hostel_Allocation.heart;
  
http.createServer(function (req, res) {  ///server to put values on so another program can grab them. 
    res.write(str); 
    res.end(); 
}).listen(8080);
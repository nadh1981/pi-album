const { Connection, Request } = require("tedious");

// Create connection to database
const config = {
  authentication: {
    options: {
      userName: "sa", // The username for the SQL Database
      password: "magiczac" // The password for the SQL Database
    },
    type: "default"
  },
  server: "localhost", // Where the server is located
  options: {
    database: "Sample", //The database name 
    encrypt: true
  }
};

/* 
    //Use Azure VM Managed Identity to connect to the SQL database
    const config = {
        server: process.env["db_server"],
        authentication: {
            type: 'azure-active-directory-msi-vm',
        },
        options: {
            database: process.env["db_database"],
            encrypt: true,
            port: 1433
        }
    };

    //Use Azure App Service Managed Identity to connect to the SQL database
    const config = {
        server: process.env["db_server"],
        authentication: {
            type: 'azure-active-directory-msi-app-service',
        },
        options: {
            database: process.env["db_database"],
            encrypt: true,
            port: 1433
        }
    });

*/

const connection = new Connection(config);

// Attempt to connect to database and execute queries if connection goes through
connection.on("connect", err => {
  if (err) {
    console.error(err.message);
  } else {
    dor();
  }
});

connection.connect();


function dor() {
  
  var x = (function(){
    console.log("Reading rows from the Table...");

  // Read all rows from table
  var request = new Request(
    'select heartrate from  heartratefor1032021', /// This is the SQL query to grab the heartrate columm and its values 
    (err, rowCount) => {
      if (err) {
        console.error(err.message);
      } else {
        console.log(`${rowCount} row(s) returned`);
      }
    }
  );
    request.on("row", columns => {
      columns.forEach(column => {
      // console.log("%s\t%s", column.metadata.colName, column.value);

       let min = [column.value] //// refernce to the columm heartrate values in database
       console.log(min); ///This prints out onto the console the values in the heartrate 
  
     var hear = [];
  for (let i = 0; i < min.length; i++) { ///push heartrate values into hear array
   hear.push(min[i])
  /// console.log("heart: "+hear);
 }
 console.log("heart: "+hear);

      });
    });
 
   connection.execSql(request);
    var heart = hear; // I want this to equal hear put nothing is being filled in hear even tried global var. 
    ////Below array is what I should be in var heart but it is empty. 
   var array = [73,71,66,66,65,65,66,67,64,64,66,65,64,90,70,61,62,66,64,61,62,61,68,63,62,64,65,64,64,68,63,65,63,61,65,62,61,62,61,62,62,63,66,62,62,60,61,61,61,62,62,62,62,68,72,63,66,60,61,60,61,60,61,62,61,62,63,64,60,61,61,61,61,62,61,63,61,58,58,57,61,64,67,61,62,63,61,59,58,60,62,61,60,64,63,62,61,62,61,62,62,61,60,59,59,59,59,59,57,56,56,57,56,57,57,57,57,57,56,57,57,59,59,58,59,59,58,60,58,58,59,60,59,58,65,63,63,57,55,55,60,58,58,59,56,55,57,57,57,59,58,57,61,61,63,62,61,63,62,63,63,61,61,60,61,60,60,58,59,61,61,62,59,60,60,61,59,61,60,58,59,60,61,60,60,60,60,61,59,61,55,56,59,64,57,58,58,56,57,58,56,54,55,58,54,58,58,60,66,65,61,59,57,59,58,61,66,60,58,55,56,57,59,56,58,59,59,58,60,59,59,57,58,58,59,58,57,59,59,59,64,67,64,61,59,63,76]
     return array; /// This should return the hear array so that it can be sent to other page and display the heartrate values.
  })(); 
  return x;
}

var t = dor();

var Student = {
  age : [4,3,2],
  heart : t
};
module.exports = {Student}; /// This exports the array what is defined in function and allows the other page to grab these values.



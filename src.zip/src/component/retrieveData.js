import React, {useState, useEffect, Component }from "react";
import { getCurrentDate, getCurrentDay, isItDaytime } from "./utilities.js";
import axios from 'axios';

function getRandomIndex(index){
    return index = Math.floor((Math.random() * 4) + 0);
  }
 
class ButtonHeartrate extends Component {
    constructor(props) {
        super(props)
        this.state = {
            heartColourB: "",
            stepsColourB: "",
            sleepColourB: "",
            heartColourN: "",
            stepsColourN: "",
            sleepColourN: "",
            heartColourI: "",
            stepsColourI: "",
            sleepColourI: ""
        }
    }

    
    componentDidMount() {
        var i = 0

        //BELINDA COLOURS
        axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
        .then(heartResponse => {
            console.log(heartResponse)
            this.setState({heartColourB: heartResponse.data})
        })
        .catch(error => {
            console.log(error)
        })

        axios.get('http://127.0.0.1:8000/colour/steps/')
            .then(stepsResponse => {
            console.log(stepsResponse)
            this.setState({stepsColourB: stepsResponse.data})
            })
            .catch(error => {
            console.log(error)
            })

            axios.get('http://127.0.0.1:8000/colour/sleep/')
            .then(sleepResponse => {
                console.log(sleepResponse)
                this.setState({sleepColourB: sleepResponse.data})
            })
            .catch(error => {
                console.log(error)
            })


            //NATHAN COLOURS
            axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
                .then(heartResponse => {
                console.log(heartResponse)
                this.setState({heartColourN: heartResponse.data})
                })
                .catch(error => {
                console.log(error)
                })

                axios.get('http://127.0.0.1:8000/colour/steps/')
                .then(stepsResponse => {
                    console.log(stepsResponse)
                    this.setState({stepsColourN: stepsResponse.data})
                })
                .catch(error => {
                    console.log(error)
                })

                axios.get('http://127.0.0.1:8000/colour/sleep/')
                    .then(sleepResponse => {
                    console.log(sleepResponse)
                    this.setState({sleepColourN: sleepResponse.data})
                    })
                    .catch(error => {
                    console.log(error)
                    })



                    //ISAAC COLOURS
                    axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
                    .then(heartResponse => {
                        console.log(heartResponse)
                        this.setState({heartColourI: heartResponse.data})
                    })
                    .catch(error => {
                        console.log(error)
                    })

                    axios.get('http://127.0.0.1:8000/colour/steps/')
                        .then(stepsResponse => {
                        console.log(stepsResponse)
                        this.setState({stepsColourI: stepsResponse.data})
                        })
                        .catch(error => {
                        console.log(error)
                        })

                        axios.get('http://127.0.0.1:8000/colour/sleep/')
                        .then(sleepResponse => {
                            console.log(sleepResponse)
                            this.setState({sleepColourI: sleepResponse.data})
                        })
                        .catch(error => {
                            console.log(error)
                        })

    }
    


} 
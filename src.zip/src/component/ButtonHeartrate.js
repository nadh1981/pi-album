import React, {useState, useEffect, Component }from "react";
import { getCurrentDate, getCurrentDay, isItDaytime } from "./utilities.js";
import axios from 'axios';
import styled from "styled-components";
import { Link } from "@chakra-ui/react"

//components are classes that specify HTML that is reusable. 
//route determines what the URL shows.




function getRandomIndex(index){
  return index = Math.floor((Math.random() * 4) + 0);
}

class ButtonHeartrate extends Component {
  constructor(props) {
      super(props)
      this.state = {
        heartColourB: "",
        stepsColourB: "",
        sleepColourB: "",
        heartColourN: "",
        stepsColourN: "",
        sleepColourN: "",
        heartColourI: "",
        stepsColourI: "",
        sleepColourI: ""
      }
  }

    componentDidMount() {
    var i = 0

    //BELINDA COLOURS
    axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
      .then(heartResponse => {
        console.log(heartResponse)
        this.setState({heartColourB: heartResponse.data})
      })
      .catch(error => {
        console.log(error)
      })

      axios.get('http://127.0.0.1:8000/colour/steps/')
        .then(stepsResponse => {
          console.log(stepsResponse)
          this.setState({stepsColourB: stepsResponse.data})
        })
        .catch(error => {
          console.log(error)
        })

        axios.get('http://127.0.0.1:8000/colour/sleep/')
          .then(sleepResponse => {
            console.log(sleepResponse)
            this.setState({sleepColourB: sleepResponse.data})
          })
          .catch(error => {
            console.log(error)
          })


          //NATHAN COLOURS
          axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
            .then(heartResponse => {
              console.log(heartResponse)
              this.setState({heartColourN: heartResponse.data})
            })
            .catch(error => {
              console.log(error)
            })

            axios.get('http://127.0.0.1:8000/colour/steps/')
              .then(stepsResponse => {
                console.log(stepsResponse)
                this.setState({stepsColourN: stepsResponse.data})
              })
              .catch(error => {
                console.log(error)
              })

              axios.get('http://127.0.0.1:8000/colour/sleep/')
                .then(sleepResponse => {
                  console.log(sleepResponse)
                  this.setState({sleepColourN: sleepResponse.data})
                })
                .catch(error => {
                  console.log(error)
                })



                //ISAAC COLOURS
                axios.get('http://127.0.0.1:8000/colour/heart/' + getRandomIndex(i))
                  .then(heartResponse => {
                    console.log(heartResponse)
                    this.setState({heartColourI: heartResponse.data})
                  })
                  .catch(error => {
                    console.log(error)
                  })

                  axios.get('http://127.0.0.1:8000/colour/steps/')
                    .then(stepsResponse => {
                      console.log(stepsResponse)
                      this.setState({stepsColourI: stepsResponse.data})
                    })
                    .catch(error => {
                      console.log(error)
                    })

                    axios.get('http://127.0.0.1:8000/colour/sleep/')
                      .then(sleepResponse => {
                        console.log(sleepResponse)
                        this.setState({sleepColourI: sleepResponse.data})
                      })
                      .catch(error => {
                        console.log(error)
                      })


  }





  render() {


    const {heartColourB, stepsColourB, sleepColourB,
      heartColourN, stepsColourN, sleepColourN,
      heartColourI, stepsColourI, sleepColourI } = this.state

      //BELINDA STYLES
    const CustomHeartButtonB = styled.a`
      display: inline-block;
      border-radius: 3px;
      padding: 0.5rem 0;
      margin: 0.5rem 1rem;
      width: 13rem;
      height:2rem;
      border: 2px solid ${props => heartColourB};
      background ${props => heartColourB};
    `
    const CustomStepsButtonB = styled.a`
      display: inline-block;
      border-radius: 3px;
      padding: 0.5rem 0;
      margin: 0.5rem 1rem;
      width: 13rem;
      height:2rem;
      border: 2px solid ${props => stepsColourB};
      background ${props => stepsColourB};
      `
      const CustomSleepButtonB = styled.a`
        display: inline-block;
        border-radius: 3px;
        padding: 0.5rem 0;
        margin: 0.5rem 1rem;
        width: 13rem;
        height:2rem;
        border: 2px solid ${props => sleepColourB};
        background ${props => sleepColourB};
        `





        //BELINDA STYLES
      const CustomHeartButtonN = styled.a`
        display: inline-block;
        border-radius: 3px;
        padding: 0.5rem 0;
        margin: 0.5rem 1rem;
        width: 13rem;
        height:2rem;
        border: 2px solid ${props => heartColourN};
        background ${props => heartColourN};
      `
      const CustomStepsButtonN = styled.a`
        display: inline-block;
        border-radius: 3px;
        padding: 0.5rem 0;
        margin: 0.5rem 1rem;
        width: 13rem;
        height:2rem;
        border: 2px solid ${props => stepsColourN};
        background ${props => stepsColourN};
        `
        const CustomSleepButtonN = styled.a`
          display: inline-block;
          border-radius: 3px;
          padding: 0.5rem 0;
          margin: 0.5rem 1rem;
          width: 13rem;
          height:2rem;
          border: 2px solid ${props => sleepColourN};
          background ${props => sleepColourN};
          `





          //ISAAC STYLES
        const CustomHeartButtonI = styled.a`
          display: inline-block;
          border-radius: 3px;
          padding: 0.5rem 0;
          margin: 0.5rem 1rem;
          width: 13rem;
          height:2rem;
          border: 2px solid ${props => heartColourI};
          background ${props => heartColourI};
        `
        const CustomStepsButtonI = styled.a`
          display: inline-block;
          border-radius: 3px;
          padding: 0.5rem 0;
          margin: 0.5rem 1rem;
          width: 13rem;
          height:2rem;
          border: 2px solid ${props => stepsColourI};
          background ${props => stepsColourI};
          `
          const CustomSleepButtonI = styled.a`
            display: inline-block;
            border-radius: 3px;
            padding: 0.5rem 0;
            margin: 0.5rem 1rem;
            width: 13rem;
            height:2rem;
            border: 2px solid ${props => sleepColourI};
            background ${props => sleepColourI};
            `




    return (
          <div className="container-fluid" style={{ height: "100%" }}>
            {/* LEFT SIDE MENU */}

            <div className="row h-100">
              <div
                className="col-3"
                style={{ backgroundColor: "#001a33" }}>
                <div className="row firstRow">
                  <div
                    className="col-12 text-center w-75 mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}
                  >
                    {getCurrentDay()}
                    <br />
                    {getCurrentDate()}
                  </div>
                </div>

                {/* PATIENT 1 NAME  */}
                <div className="row mt-4" style={{ height: "10%" }}>
                  <div
                    className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "white",
                      backgroundColor: "rgba(77,77,77,0.4)",
                      borderRadius: "15px",
                    }}
                  >
                    Belinda
                  </div>
                </div>

                {/* PATIENT 2 NAME */}
                <div className="row mt-4" style={{ height: "10%" }}>
                  <div
                    className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "white",
                      backgroundColor: "rgba(77,77,77,0.4)",
                      borderRadius: "15px",
                    }}
                  >
                    Nathan
                  </div>
                </div>

                {/* PATIENT 3 NAME */}
                <div className="row mt-4" style={{ height: "10%" }}>
                  <div
                    className="col-12  text-center w-75 mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "white",
                      backgroundColor: "rgba(77,77,77,0.4)",
                      borderRadius: "15px",
                    }}
                  >
                    Isaac
                  </div>
                </div>
              </div>



              {/* RIGHT SIDE MENU */}

              <div
                className="col-9"
                style={{ backgroundColor: "#e9eff5"}}
              >


              {/* DAY (TOP OF SCREEN) */}
                <div
                  className="row secondRow"
                  style={{ marginTop: "9%", height: "4%" }}
                >
                  <div
                    className="col-11 text-center mx-auto d-flex align-items-center justify-content-left"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}
                  >
                    <strong>Day</strong>
                  </div>
                </div>



                {/* COLUMN ONE-- HEART */}

                <div className="row secondColumn">
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                      maxHeight: "100%",
                      position: "relative",
                    }}
                  >
                    <img
                      className="img-fluid"
                      style={{ height: "30%" }}
                      src={"/Agecare-icons-heart1.png"}
                      alt="Heart rate"
                    ></img>
                    <span
                      style={{
                        position: "absolute",
                        bottom: "10%",
                        display: "inline-block",
                      }}
                    >
                      <strong>Heart Rate</strong>
                    </span>
                  </div>


                  {/* COLUMN TWO -- STEPS */}

                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                      maxHeight: "100%",
                      position: "relative",
                    }}
                  >
                    <img
                      className="img-fluid"
                      style={{ height: "30%" }}
                      src={"/Agecare-icons-steps.png"}
                      alt="Heart rate"
                    ></img>
                    <span
                      style={{
                        position: "absolute",
                        bottom: "10%",
                        display: "inline-block",
                      }}
                    >
                      <strong>Steps</strong>
                    </span>
                  </div>



                  {/* COLUMN THREE -- SLEEP */}

                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                      maxHeight: "100%",
                      position: "relative",
                    }}
                  >
                    <img
                      className="img-fluid"
                      style={{ height: "30%" }}
                      src={"/Agecare-icons-sleep.png"}
                      alt="Heart rate"
                    ></img>
                    <span
                      style={{
                        position: "absolute",
                        bottom: "10%",
                        display: "inline-block",
                      }}
                    >
                      <strong>Sleep</strong>
                    </span>
                  </div>
                </div>




                {/* FIRST ROW OF BUTTONS */}

                <div className="row mt-4" style={{ height: "10%" }}>

                {/* BELINDA HEART BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                    <CustomHeartButtonB href="heartrate">
                    </CustomHeartButtonB>
                  </div>


                  {/* BELINDA STEPS BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                  <CustomStepsButtonB href="steps">
                  </CustomStepsButtonB>
                  </div>


                  {/* BELINDA SLEEP BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>
                  <CustomSleepButtonB href="sleep">
                  </CustomSleepButtonB>
                  </div>
                </div>


                {/* SECOND ROW OF BUTTONS */}

                <div className="row mt-4" style={{ height: "10%" }}>

                {/* NATHAN HEART BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                    <CustomHeartButtonN href="heartrate">
                    </CustomHeartButtonN>
                  </div>


                  {/* NATHAN STEPS BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                  <CustomStepsButtonN href="steps">
                  </CustomStepsButtonN>
                  </div>


                  {/* NATHAN SLEEP BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>
                  <CustomSleepButtonN href="sleep">
                  </CustomSleepButtonN>
                  </div>
                </div>



                {/* THIRD ROW OF BUTTONS */}

                <div className="row mt-4" style={{ height: "10%" }}>

                {/* ISAAC HEART BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                    <CustomHeartButtonI href="heartrate">
                    </CustomHeartButtonI>
                  </div>


                  {/* ISAAC STEPS BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>

                  <CustomStepsButtonI href="steps">
                  </CustomStepsButtonI>
                  </div>


                  {/* ISAAC SLEEP BUTTON */}
                  <div
                    className="col-3 text-center mx-auto d-flex align-items-center justify-content-center"
                    style={{
                      color: "black",
                      backgroundColor: "white",
                      borderRadius: "15px",
                    }}>
                  <CustomSleepButtonI href="sleep">
                  </CustomSleepButtonI>
                  </div>
                </div>






              </div>
            </div>
          </div>
    )
  }
}





export default ButtonHeartrate

import { createTheme } from '@mui/system';
import { BrowserRouter as Router,Route,Switch } from 'react-router-dom';
import HeartData from './component/data/heartData';
import StepsData from './component/data/stepsData';
import SleepData from './component/data/sleepData';
import Dashboard from "./component/Dashboard";
import NotFound from './NotFound';

function App() {
  return (
  
     <Router>
       <Switch>
         <Route exact path="/">
            <Dashboard/>
         </Route>

         <Route exact path="/heart">
            <HeartData/>
         </Route>

         <Route exact path="/sleep">
            <SleepData/>
         </Route>
         
         <Route exact path="/steps">
            <StepsData/>
         </Route>
         
         <Route path="*">
           <NotFound/>
         </Route>
       </Switch>
     </Router>
  
  );
}

export default App;

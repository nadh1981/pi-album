export function getCurrentDate() {
    let newDate = new Date();
    let date = newDate.getDate();
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    let month = newDate.getMonth();
  
    let year = newDate.getFullYear();
  
    return `${date}th ${months[month]} ${year}`;
  }
  
  export function getCurrentDay() {
    let newDate = new Date();
    const days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    let day = newDate.getDay();
  
    return `${days[day]}`;
  }
  
  export function isItDaytime() {
    let newDate = new Date();
    let hour = newDate.getHours();
    if (hour > 6 && hour < 21) {
      return true;
    }
    return false;
  }
  